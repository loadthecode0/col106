case $MACHTYPE in (x86_64*) r=64;; esac
./Matrix$r 100 100.wrk
