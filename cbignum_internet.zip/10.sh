case $MACHTYPE in (x86_64*) r=64;; esac
./Matrix$r 10 10.wrk
