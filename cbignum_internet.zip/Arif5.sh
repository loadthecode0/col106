case $MACHTYPE in (x86_64*) r=64;; esac
./Arifexp$r -high -size -time -mhz 2000 Arif5 >Arif5.wrk
