case $MACHTYPE in (x86_64*) r=64;; esac
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.9
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.8
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.7
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.6
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.5
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.4
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.3
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.2
read
./Miller$r -idle $1 $2 $3 $4 $5 $6 $7 $8 $9 Miller.1
read
