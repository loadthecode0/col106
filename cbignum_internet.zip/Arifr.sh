case $MACHTYPE in (x86_64*) r=64;; esac
./Arifexp$r -hexo -par 2 Arifr >Arifr.wrk
