case $MACHTYPE in (x86_64*) r=64;; esac
./Arifexp$r -high -size -time -mhz 2000 Arif4 >Arif4.wrk
